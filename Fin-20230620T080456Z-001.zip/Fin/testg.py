import cv2


def process_video(video_path):
    cap = cv2.VideoCapture(video_path)

    frame_list = []
    while cap.isOpened():
        ret, frame = cap.read()

        if not ret:
            break

        frame_list.append(False)  # Append False for each frame

    cap.release()
    return frame_list


# Example usage
video_path = "videos/4.mp4"
frames = process_video(video_path)

print(len(frames))