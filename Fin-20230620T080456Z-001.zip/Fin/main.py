import math
import cv2
import numpy as np
from ultralytics import YOLO
from ultralytics.yolo.utils.plotting import Annotator

from deep_sort import preprocessing

from deep_sort import nn_matching
from deep_sort.detection import Detection
from deep_sort.tracker import Tracker
from tools import generate_detections as gdet

from numpy import *

# 3d
import torchvision.models as models
from lib.DataUtils import *
from lib.Utils import *
from lib import Model, ClassAverages

from shapely.geometry import Polygon

def main():
    cap = cv2.VideoCapture("videos/3.mp4")


    # get vcap property
    width = 1280
    height = 720

    # output video
    outputFPS = 15.0
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    out = cv2.VideoWriter('videos/o4t4.mp4', fourcc,
                          outputFPS, (width, height))
#


    model = YOLO("yolov8n.pt")

    seg_model = YOLO('yolov8n-seg.pt')

    rng = np.random.default_rng(3)
    colors = rng.uniform(0, 255, size=(80, 3))

    # Definition of the parameters
    max_cosine_distance = 0.5
    nn_budget = None
    nms_max_overlap = 1.0
    bins_no = 2

    # initialize deep sort
    model_filename = 'model_data/mars-small128.pb'
    encoder = gdet.create_box_encoder(model_filename, batch_size=1)
    metric = nn_matching.NearestNeighborDistanceMetric("cosine", max_cosine_distance, nn_budget)
    tracker = Tracker(metric)

    cal_dir = 'Kitti/camera_cal/'
    calib_path = os.path.abspath(os.path.dirname(__file__)) + "/" + cal_dir
    calib_file = calib_path + "calib_cam_to_cam.txt"

    use_cuda = torch.cuda.is_available()
    device = torch.device("cuda" if use_cuda else "cpu")

    weights_path = os.path.abspath(os.path.dirname(__file__)) + '/weights'
    weight_list = [x for x in sorted(os.listdir(weights_path)) if x.endswith('.pkl')]
    if len(weight_list) == 0:
        print('We could not find any model weight to load, please train the model first!')
        exit()
    else:
        print('Using model weights : %s' % weight_list[-1])
        my_vgg = models.vgg19_bn()
        d3model = Model.Model(features=my_vgg.features, bins=bins_no).to(device)
        if use_cuda:
            checkpoint = torch.load(weights_path + '/%s' % weight_list[-1])
        else:
            checkpoint = torch.load(weights_path + '/%s' % weight_list[-1], map_location='cpu')
        d3model.load_state_dict(checkpoint['model_state_dict'])
        d3model.eval()

    averages = ClassAverages.ClassAverages()
    angle_bins = generate_bins(bins_no)

    coord = {}
    count = 0
    tot = -1

    fps = int(cap.get(cv2.CAP_PROP_FPS))

    dt = 1.0 / fps
    v = dt * 2  # 2 is good
    a_3d = 0.5 * dt ** 2  # 0.5*dt**2 is good


  # output_warnings = [ ]
    frame_count = 1

    while(cap.isOpened()):
        success, frame = cap.read()

        if (not success):
            return

        if (frame_count >= 30 / outputFPS):
            frame_count = 1
        else:
            frame_count += 1
            continue


        #testing_ ground truth

        ground_truth = [False] * outputFPS
        predefined = [1, 3, 6]
        for i in range(len(ground_truth)):
            if i in predefined:
                ground_truth[i] = True

        tot = tot + 1

        height, width = frame.shape[:2]
        frame_area = width * height

        results = model.predict(frame, agnostic_nms=True)
        annotator = Annotator(frame, 4, 4)

        boxes = []
        scores = []
        names = []

        cv2.line(frame, (314, 720), (540, 604), (247, 44, 200), 2)
        cv2.line(frame, (540, 604), (740, 604), (247, 44, 200), 2)
        cv2.line(frame, (740, 604), (976, 720), (247, 44, 200), 2)

        for info in results:
            parameters = info.boxes
            for box in parameters:
                x1, y1, x2, y2 = box.xyxy[0]
                confidence = box.conf[0]
                conf = math.ceil(confidence * 100)
                class_detect = model.names[int(box.cls[0])]
                if conf >= 25:
                    x1, y1, x2, y2 = int(x1), int(y1), int(x2), int(y2)
                    color = [int(c) for c in colors[int(box.cls[0])]]
                    b = box.xyxy[0]  # get box coordinates in (top, left, bottom, right) format
                    # annotator.box_label(b, class_detect, color=color)

                    boxes.append([x1, y1, int(x2-x1), int(y2-y1)])
                    scores.append(conf)
                    names.append(class_detect)

        features = encoder(frame, boxes)
        detections = [Detection(bbox, score, class_name, feature) for bbox, score, class_name, feature in
                      zip(boxes, scores, names, features)]

        # run non-maxima suppresion
        boxs = np.array([d.tlwh for d in detections])
        scores = np.array([d.confidence for d in detections])
        classes = np.array([d.class_name for d in detections])
        indices = preprocessing.non_max_suppression(boxs, classes, nms_max_overlap, scores)
        detections = [detections[i] for i in indices]

        # Call the tracker
        tracker.predict()
        tracker.update(detections)

        ls = []  # to get the track ids of each frame

        index = -1
        i = -1

        for track in tracker.tracks:

            temp_box = track.to_tlbr()

            #############################################################

            # cv2.rectangle(img, (int(temp_box[0]), int(temp_box[1])), (int(temp_box[2]), int(temp_box[3])), (0, 255, 0), 2)
            # cv2.putText(img, str(track.track_id)+" " +track.class_name , (int(temp_box[0]), int(temp_box[1])), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 0, 0), 2, cv2.LINE_AA)

            bbox = [int(temp_box[0]), int(temp_box[1]), int(temp_box[2]), int(temp_box[3])]
            box_2d = [(bbox[0], bbox[1]), (bbox[2], bbox[3])]

            try:
                object = DetectedObject(frame, track.class_name, box_2d, calib_file)
            except Exception as e:
                print(e)
                continue

            theta_ray = object.theta_ray
            input_img = object.img
            proj_matrix = object.proj_matrix
            if (track.class_name == 'person'):
                detected_class = 'pedestrian'
            else:
                detected_class = 'car'

            input_tensor = torch.zeros([1, 3, 224, 224]).to(device)
            input_tensor[0, :, :, :] = input_img

            [orient, conf, dim] = d3model(input_tensor)
            orient = orient.cpu().data.numpy()[0, :, :]
            conf = conf.cpu().data.numpy()[0, :]
            dim = dim.cpu().data.numpy()[0, :]
            dim += averages.get_item(detected_class)

            argmax = np.argmax(conf)
            orient = orient[argmax, :]
            cos = orient[0]
            sin = orient[1]
            alpha = np.arctan2(sin, cos)
            alpha += angle_bins[argmax]
            alpha -= np.pi

            location, X = calc_location(dim, proj_matrix, box_2d, alpha, theta_ray)

            kalman = cv2.KalmanFilter(9, 3, 0)

            kalman.measurementMatrix = np.array([
                [1, 0, 0, v, 0, 0, a_3d, 0, 0],
                [0, 1, 0, 0, v, 0, 0, a_3d, 0],
                [0, 0, 1, 0, 0, v, 0, 0, a_3d]
            ], np.float32)

            kalman.transitionMatrix = np.array([
                [1, 0, 0, v, 0, 0, a_3d, 0, 0],
                [0, 1, 0, 0, v, 0, 0, a_3d, 0],
                [0, 0, 1, 0, 0, v, 0, 0, a_3d],
                [0, 0, 0, 1, 0, 0, v, 0, 0],
                [0, 0, 0, 0, 1, 0, 0, v, 0],
                [0, 0, 0, 0, 0, 1, 0, 0, v],
                [0, 0, 0, 0, 0, 0, 1, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 1, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 1]
            ], np.float32)

            kalman.processNoiseCov = np.array([
                [1, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 1, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 1, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 1, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 1, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 1, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 1, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 1, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 1]
            ], np.float32) * 0.007

            kalman.measurementNoiseCov = np.array([
                [1, 0, 0],
                [0, 1, 0],
                [0, 0, 1]
            ], np.float32) * 0.1

            kalman.statePre = np.array([
                [np.float32(location[0])], [np.float32(location[1])], [np.float32(location[2])]
                , [np.float32(location[0])], [np.float32(location[1])], [np.float32(location[2])]
                , [np.float32(location[0])], [np.float32(location[1])], [np.float32(location[2])]
            ])

            # plot_regressed_3d_bbox(img, proj_matrix, box_2d, dim, alpha, theta_ray)

            print('Estimated pose: %s' % location)
            # Create the measurement
            measurement = np.array([
                [np.float32(location[0])],
                [np.float32(location[1])],
                [np.float32(location[2])]
            ])
            kalman.correct(measurement)
            tp = kalman.predict()

            # Update the estimated pose with the corrected values
            location[0] = tp[0].item()
            location[1] = tp[1].item()
            location[2] = tp[2].item()

            print('Corrected pose: %s' % location)

            _, box_coordinates = plot_regressed_3d_bbox(frame, proj_matrix, box_2d, dim, alpha, theta_ray,
                                                        color=cv_colors.RED.value, location=location)

            ###############################################################

            i = i + 1

            point1x = box_coordinates[0][0]
            point1y = box_coordinates[0][1]
            point2x = box_coordinates[1][0]
            point2y = box_coordinates[1][1]
            point3x = box_coordinates[4][0]
            point3y = box_coordinates[4][1]
            point4x = box_coordinates[5][0]
            point4y = box_coordinates[5][1]

            point1xArr = []
            point1yArr = []
            point2xArr = []
            point2yArr = []
            point3xArr = []
            point3yArr = []
            point4xArr = []
            point4yArr = []

            x_min = []
            x_max = []
            y_max = []

            # cv2.rectangle(frame, (int(temp_box[0]), int(temp_box[1])), (int(temp_box[2]), int(temp_box[3])),
            #               (0, 255, 0), 2)
            # cv2.putText(frame, str(track.track_id) + " " + track.class_name, (int(temp_box[0]), int(temp_box[1])),
            #             cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 0, 0), 2, cv2.LINE_AA)
            cv2.putText(frame, str(track.track_id), (int(temp_box[0]), int(temp_box[1])),
                        cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 0, 0), 2, cv2.LINE_AA)


            ls.append(track.track_id)  # add track ids
            if track.track_id not in coord:
                coord[track.track_id] = []
            else:

                leng = len(coord[track.track_id])
                if (leng == 15):
                    coord[track.track_id].remove(coord[track.track_id][0])
                if (
                        0 < point1x < 1280 and
                        0 < point2x < 1280 and
                        0 < point3x < 1280 and
                        0 < point4x < 1280 and
                        0 < point1y < 720 and
                        0 < point2y < 720 and
                        0 < point2y < 720 and
                        0 < point2y < 720
                ):
                    coord[track.track_id].append([
                        point1x,
                        point1y,
                        point2x,
                        point2y,
                        point3x,
                        point3y,
                        point4x,
                        point4y,

                    ])

            for i in range(0, len(coord[track.track_id])):
                point1xArr.append(coord[track.track_id][i][0])
                point1yArr.append(coord[track.track_id][i][1])
                point2xArr.append(coord[track.track_id][i][2])
                point2yArr.append(coord[track.track_id][i][3])
                point3xArr.append(coord[track.track_id][i][4])
                point3yArr.append(coord[track.track_id][i][5])
                point4xArr.append(coord[track.track_id][i][6])
                point4yArr.append(coord[track.track_id][i][7])

            if (len(coord[track.track_id]) > 0):
                vehicle_area = abs((int(temp_box[2]) - int(temp_box[0])) * (
                            int(temp_box[3]) - int(temp_box[1])))
                percentage = vehicle_area / frame_area
            else:
                percentage = 0

            base = []

            if (len(point1xArr) >= 5 and tot > 4):
                for i in range(0, len(point1xArr)):
                    base.append(i + 1)

                model_1x = polyfit(base, point1xArr, 1)
                predict_1x = poly1d(model_1x)

                model_1y = polyfit(base, point1yArr, 1)
                predict_1y = poly1d(model_1y)

                model_2x = polyfit(base, point2xArr, 1)
                predict_2x = poly1d(model_2x)

                model_2y = polyfit(base, point2yArr, 1)
                predict_2y = poly1d(model_2y)

                model_3x = polyfit(base, point3xArr, 1)
                predict_3x = poly1d(model_3x)

                model_3y = polyfit(base, point3yArr, 1)
                predict_3y = poly1d(model_3y)

                model_4x = polyfit(base, point4xArr, 1)
                predict_4x = poly1d(model_4x)

                model_4y = polyfit(base, point4yArr, 1)
                predict_4y = poly1d(model_4y)

                prediction_frame_size = 30

                predicted_1 = (predict_1x(prediction_frame_size), predict_1y(prediction_frame_size))
                predicted_2 = (predict_2x(prediction_frame_size), predict_2y(prediction_frame_size))
                predicted_3 = (predict_3x(prediction_frame_size), predict_3y(prediction_frame_size))
                predicted_4 = (predict_4x(prediction_frame_size), predict_4y(prediction_frame_size))

                pts = np.array([predicted_1, predicted_2,
                                predicted_4, predicted_3],
                               np.int32)
                pts = pts.reshape((-1, 1, 2))

                # Line thickness of 2 px
                thickness = 2

                cv2.fillPoly(frame, [pts], (255, 0, 0))

                road_safety_region = Polygon([(314, 720), (540, 604), (740, 604), (976, 720)])
                vehicle_base_region = Polygon([predicted_1, predicted_2, predicted_3, predicted_4])

                if road_safety_region.intersects(vehicle_base_region):
                    cv2.putText(frame, "warning", (10, 50), cv2.FONT_HERSHEY_SIMPLEX, fontScale=2.5, thickness=5,
                                color=(255, 0, 0))
                    f = open("warntimes.txt", "a+")
                    f.write(str(count))


        count  = count +1
        out.write(frame)
        cv2.imshow('ImageWindow', frame)

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    out.release()
    # condition for check ground truth and output of the model


    cv2.destroyAllWindows()

# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    main()